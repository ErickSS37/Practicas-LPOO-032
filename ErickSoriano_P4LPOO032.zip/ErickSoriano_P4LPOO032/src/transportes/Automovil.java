/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportes;
import vehiculo.Vehiculo;

/**
 *
 * @author Dell
 */
public class Automovil extends Vehiculo{
    
    public Automovil(){
    }
    public Automovil(int gas){
        this.setMarca("Ferrari");
        this.setModelo("FXX");
        this.setColor("Rojo");
        if(this.encenderAutomovil(gas) == 1){
            do{
            }while(this.avanzaAutomovil(getCombustible()) == 1);
            cargarGas();
            do{
            }while(this.avanzaAutomovil(getCombustible()) == 1);
            this.apagarAutomovil();
        }
        else System.out.println("No Encendió");
    }
    public Automovil(int gas, int carga){
        this.setMarca("Tesla");
        this.setModelo("Model 3");
        this.setColor("Blanco");
        if( this.encenderAutomovil(gas, carga) == 1){
            do{
            }while(this.avanzaAutomovil(getCombustible(), getCarga()) == 1);
            cargarGas();
            cargarEnergia();
            do{
            }while(this.avanzaAutomovil(getCombustible(), getCarga()) == 1);
            this.apagarAutomovil();
        }
        else System.out.println("No encendió");
    }
    
    private int encenderAutomovil(int gas){
        if (gas > 1){
            System.out.println(getMarca()+" "+getModelo()+" "+getColor()+" Encendido     Gasolina " + 10*gas + "%");
            setCombustible(gas);
            return 1;
        }
        else
            System.out.println("No hay suficiente gasolina");
        return 0;
    }
    private int avanzaAutomovil(int gas){
        if (gas > 1){
            setCombustible(--gas);
            System.out.println("Acelerando      Gasolina " + 10*gas + "%");
            return 1;
        }
        else
            System.out.println("No hay suficiente gasolina");
        return 0;
    }
    private void cargarGas() {
        System.out.println("Cargando Combustible");
        setCombustible(10);
        System.out.println("Combustible Cargado");
    }
    private void apagarAutomovil(){
        System.out.println("Automovil Apagado");
    }
    
    private int encenderAutomovil(int gas, int carga) {
        if ((gas > 1) && (carga > 1)){
            System.out.println(getMarca()+" "+getModelo()+" "+getColor()+" Encendido     Gasolina " + 10*gas + "% Batería" + 10*carga + "%");
            setCombustible(gas);
            setCarga(carga);
            return 1;
        } 
        if(1 > carga)
            System.out.println("No hay suficiente carga en la batería");
        else
            System.out.println("No hay suficiente gasolina");
        return 0;
    }
    private int avanzaAutomovil(int gas, int carga) {
        if ((gas > 1) && (carga > 1)){
            setCombustible(--gas);
            setCarga(--carga);
            System.out.println("Acelerando      Gasolina " + 10*gas + "% Batería" + 10*carga + "%");
            return 1;
        }
        if(carga == 1)
            System.out.println("No hay suficiente carga en la batería");
        if (gas == 1)
            System.out.println("No hay suficiente gasolina");
        return 0;
    }
    private void cargarEnergia() {
        System.out.println("Cargando Batería");
        setCarga(10);
        System.out.println("Batería Cargada");
    }

    
    
    
}
