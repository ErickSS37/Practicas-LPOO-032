/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

/**
 *
 * @author Dell
 */
public class Automotor {

    /**
     * @return the gas
     */
    public double getGas() {
        return gas;
    }

    /**
     * @param gas the gas to set
     */
    public void setGas(double gas) {
        this.gas = gas;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    private String modelo;
    private String marca;
    private double gas;
    
    public String encender(double gas){
        System.out.println("Encendiendo...");
        if(gas > 1){
            setGas(gas);
            return "Encendido";
        }
        return "No enciende";
    }
    public String apagar(){
        System.out.println("Apagando...");
        return "Apagado";
    }
    public void acelerar(double gas){
        gas = gas - 1;
        setGas(gas);
    }
    public void frenar(){
        System.out.println("Frenando...");
    }
}
