/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class Automovil extends Automotor{
    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    private String color;
    private double precio;
    
    public String avanza(double gas){
        if(gas > 1){
            setGas(--gas);
            return "Avanzando";
        }
        return "Hace falta cargar combustible";
    }
    public String avanzaDerecha(double gas){
        if(gas > 1){
            acelerar(gas);
            return "Girando a la derecha";
        }
        return "Hace falta cargar combustible";
    }
    public String avanzaIzquierda(double gas){
        if(gas > 1){
            acelerar(gas);
            return "Girando a la izquierda";
        }
        return "Hace falta cargar combustible";
    }
}
