/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Arreglos;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class RunArreglos {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        Automovil[] audi = new Automovil[2];
        
        for(int i = 0; i < audi.length; i++){
            audi[i] = new Automovil();
            System.out.println("Ingrese la información del automovil "+Integer.toString(i+1)+":");
            System.out.println("Marca:");
            audi[i].setMarca(entrada.next());
            System.out.println("Modelo:");
            audi[i].setModelo(entrada.next());
            System.out.println("Color:");
            audi[i].setColor(entrada.next());
            System.out.println("Precio:");
            audi[i].setPrecio(entrada.nextDouble());
            System.out.println("Combustible cargado:");
            audi[i].setGas(entrada.nextDouble());
        }
        for(Automovil auto:audi){
            System.out.println("");
            System.out.print(auto.getMarca()+" ");
            System.out.print(auto.getModelo()+" ");
            System.out.print(auto.getColor()+" ");
            System.out.print("$"+Double.toString(auto.getPrecio())+" ");
            System.out.println("Combustible:"+Double.toString(auto.getGas()*10)+"%");
            System.out.println("");
            System.out.println(auto.encender(auto.getGas()));
            while(auto.getGas() > 2){
                System.out.println(auto.avanza(auto.getGas()));
            }
            System.out.println(auto.avanzaDerecha(auto.getGas()));
            auto.frenar();
            auto.apagar();
            
        }
    }
    
}
