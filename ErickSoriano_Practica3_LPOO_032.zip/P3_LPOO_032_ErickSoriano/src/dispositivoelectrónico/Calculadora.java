/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dispositivoelectrónico;

/**
 *
 * @author Dell
 */
public class Calculadora extends DispositivoElectronico implements IOperacionesAritmeticas, IOperacionesAvanzadas{

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    private String modelo;
    

    @Override
    public double suma(double a, double b) {
        return a+b;
    }

    @Override
    public double resta(double a, double b) {
        return a-b;
    }

    @Override
    public double multiplicacion(double a, double b) {
        return a*b;
    }

    @Override
    public double division(double a, double b) {
        return a/b;
    }

    @Override
    public double raiz(double a) {
        return Math.sqrt(a);
    }

    @Override
    public double potencia(double a, double b) {
        return Math.pow(a, b);
    }

    @Override
    public String encender() {
        return "Calculadora Encendida";
    }
    
}
