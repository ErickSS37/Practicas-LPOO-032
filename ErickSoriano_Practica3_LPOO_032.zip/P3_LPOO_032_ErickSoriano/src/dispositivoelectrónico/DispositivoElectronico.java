/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dispositivoelectrónico;

/**
 *
 * @author Dell
 */
public abstract class DispositivoElectronico {

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }
    private String marca = "Samsung";
    private String color = "Azul";
    
    public abstract String encender();
    public String apagar(){
        return "Dispositivo Apagado";
    }
    
    
}
