/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dispositivoelectrónico;

/**
 *
 * @author Erick
 */
public interface IOperacionesAvanzadas {
    public double raiz(double a);
    public double potencia(double a, double b);
}
