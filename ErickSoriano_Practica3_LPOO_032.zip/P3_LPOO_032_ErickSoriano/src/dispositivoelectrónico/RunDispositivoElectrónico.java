/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dispositivoelectrónico;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class RunDispositivoElectrónico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        Calculadora calc = new Calculadora();
        Telefono tel = new Telefono();
        
        tel.setMarca("Samsung");
        tel.setColor("Negro");
        
        System.out.println("Telefono " + tel.getMarca() + " " + tel.modelo + " " + tel.getColor());
        System.out.println(tel.encender());
        
        System.out.println(tel.buscarContacto("Erick"));
        System.out.println(tel.hacerLlamada("Erick"));
        System.out.println(tel.terminarLlamada());
        System.out.println("");
        System.out.println("Introduzca un primer número");
        double v1 = entrada.nextDouble();
        System.out.println("Introduzca un segundo número");
        double v2 = entrada.nextDouble();
        System.out.println("La suma " + v1 + " + " + v2 + " es igual a " + tel.suma(v1, v2));
        System.out.println("La resta " + v1 + " - " + v2 + " es igual a " + tel.resta(v1, v2));
        System.out.println("La multiplicación " + v1 + " * " + v2 + " es igual a " + tel.multiplicacion(v1, v2));
        System.out.println("La división " + v1 + " / " + v2 + " es igual a " + tel.division(v1, v2));
        
        calc.setMarca("Casio");
        calc.setColor("Azul");
        calc.setModelo("fx 570");
        System.out.println("Calculadora " + calc.getMarca() + " " + calc.getModelo() + " " + calc.getColor());
        System.out.println("Introduzca un primer número");
        v1 = entrada.nextDouble();
        System.out.println("Introduzca un segundo número");
        v2 = entrada.nextDouble();
        System.out.println("");
        System.out.println("Operaciones Básicas");
        System.out.println("La suma " + v1 + " + " + v2 + " es igual a " + calc.suma(v1, v2));
        System.out.println("La resta " + v1 + " - " + v2 + " es igual a " + calc.resta(v1, v2));
        System.out.println("La multiplicación " + v1 + " * " + v2 + " es igual a " + calc.multiplicacion(v1, v2));
        System.out.println("La división " + v1 + " / " + v2 + " es igual a " + calc.division(v1, v2));
        System.out.println("");
        System.out.println("Operaciones Avanzadas");
        System.out.println("La raíz de " + v1 + " = " + calc.raiz(v1));
        System.out.println("La raíz de " + v2 + " = " + calc.raiz(v2));
        System.out.println("La potencia " + v1 + "^" + v2 + " = " + calc.potencia(v1, v2));
    }
    
}
