/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dispositivoelectrónico;

/**
 *
 * @author Dell
 */
public class Telefono extends DispositivoElectronico implements IOperacionesAritmeticas{
    public String modelo = "Galaxy S10";
    
    public String hacerLlamada(int num){
        return "Llamando a " + num;
    }
    public String hacerLlamada(String contacto){
        return "Llamando a " + contacto;
    }
    public String terminarLlamada(){
        return "Llamada terminada";
    }
    
    public String buscarContacto(String contacto){
        return "Buscando " + contacto;
    }
    
    @Override
    public String encender() {
        return "Telefono Encendido";
    }

    @Override
    public double suma(double a, double b) {
        return a+b;
    }

    @Override
    public double resta(double a, double b) {
        return a-b;
    }

    @Override
    public double multiplicacion(double a, double b) {
        return a*b;
    }

    @Override
    public double division(double a, double b) {
        return a/b;
    }
}
