/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica10;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class RunPractica10 {

    /**
     * @param args the command line arguments
     */
    //¿Qué necesitaría la librería para hacer una conexión a base de datos?
    public static void main(String[] args) {
        // TODO code application logic here
        CalculadorEstandar ce = new CalculadorEstandar();
        Scanner entrada = new Scanner(System.in);
        double a;
        double b;
        System.out.println("Se realizaran operaciones a(operacion)b");
        System.out.println("Ingrese un primer numero \"a\"");
        a = entrada.nextDouble();
        System.out.println("Ingrese un segundo numero \"b\"");
        b = entrada.nextDouble();
        System.out.print("Suma de a+b: ");
        System.out.println(Double.toString(ce.suma( a, b)));
        System.out.print("Resta de a-b: ");
        System.out.println(Double.toString(ce.resta(a, b)));
        System.out.print("Multiplicacion de a*b: ");
        System.out.println(Double.toString(ce.multiplicacion(a , b)));
        System.out.print("Division de a/b: ");
        System.out.println(Double.toString(ce.division(a, b)));
    }
    
}
