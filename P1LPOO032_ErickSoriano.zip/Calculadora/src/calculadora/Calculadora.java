/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;
import java.util.Scanner;

/**
 *
 * @author FCFM
 */
public class Calculadora {
    /**
     * @param args the command line arguments
     */
    static Scanner entrada = new Scanner(System.in);
    
    public static void main(String[] args) {
        // TODO code application logic here
        Operaciones op = new Operaciones();
        OperacionesAvanzadas av =  new OperacionesAvanzadas();
        System.out.println("Introduce un primer número");
        double v1 = entrada.nextDouble();
        System.out.println("Introduce un segundo número");
        double v2 = entrada.nextDouble();
        
        System.out.println("class Operaciones");
        System.out.println("La suma " + v1 + " + " + v2 + " es igual a " + op.suma(v1, v2));
        System.out.println("La resta " + v1 + " - " + v2 + " es igual a " + op.resta(v1, v2));
        System.out.println("La multiplicación " + v1 + " * " + v2 + " es igual a " + op.multi(v1, v2));
        System.out.println("La división " + v1 + " / " + v2 + " es igual a " + op.divi(v1, v2));
    }
    
}
