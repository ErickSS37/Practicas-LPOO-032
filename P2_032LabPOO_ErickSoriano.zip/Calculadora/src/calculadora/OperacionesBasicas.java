/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author FCFM
 */
public class OperacionesBasicas {
    
   public double suma(double a, double b){
        return a + b;
   }
   public double resta(double a, double b){
        return a - b;
   }
   public double multi(double a, double b){
        return a * b;
   }
   public double divi(double a, double b){
        return a / b;
   }
}
