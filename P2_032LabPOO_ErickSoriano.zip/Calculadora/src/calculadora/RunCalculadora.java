/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;
import java.util.Scanner;

/**
 *
 * @author FCFM
 */
public class RunCalculadora {
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        Calculadora calc = new Calculadora();
        CalculadoraCientifica cient =  new CalculadoraCientifica();
        System.out.println("Introduzca un primer número");
        double v1 = entrada.nextDouble();
        System.out.println("Introduzca un segundo número");
        double v2 = entrada.nextDouble();
        
        System.out.println("Clase Calculadora");
        System.out.println("La suma " + v1 + " + " + v2 + " es igual a " + calc.suma(v1, v2));
        System.out.println("La resta " + v1 + " - " + v2 + " es igual a " + calc.resta(v1, v2));
        System.out.println("La multiplicación " + v1 + " * " + v2 + " es igual a " + calc.multi(v1, v2));
        System.out.println("La división " + v1 + " / " + v2 + " es igual a " + calc.divi(v1, v2));
        System.out.println("");
        System.out.println("Clase Calculadora Científica");
        System.out.println("La suma " + v1 + " + " + v2 + " es igual a " + cient.suma(v1, v2));
        System.out.println("La resta " + v1 + " - " + v2 + " es igual a " + cient.resta(v1, v2));
        System.out.println("La multiplicación " + v1 + " * " + v2 + " es igual a " + cient.multi(v1, v2));
        System.out.println("La división " + v1 + " / " + v2 + " es igual a " + cient.divi(v1, v2));
        System.out.println("La raíz de " + v1 + " = " + cient.raiz(v1));
        System.out.println("La raíz de " + v2 + " = " + cient.raiz(v2));
        System.out.println("La potencia " + v1 + "^" + v2 + " = " + cient.potencia(v1, v2));
    }
}
