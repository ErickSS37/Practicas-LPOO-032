/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author jorgeislas
 */
public abstract class ComponenteElectronico {

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the volumen
     */
    public int getVolumen() {
        return volumen;
    }

    /**
     * @param volumen the volumen to set
     */
    public void setVolumen(int volumen) {
        this.volumen = volumen;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    private String modelo;
    private String marca;
    private int volumen;
    
    
    public abstract String encender();
    public String subirVolumen(int vol){
        vol = vol+10;
        setVolumen(vol);
        return "Subiendo volumen "+Integer.toString(vol)+"%";
    }
    public String bajarVolumen(int vol){
        vol = vol-10;
        setVolumen(vol);
        return "Bajando volumen "+Integer.toString(vol)+"%";
    }
    
}
