/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author jorgeislas
 */
public class Computadora  extends ComponenteElectronico implements IOtrosComponentesE{

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    private String usuario; 
    
    @Override
    public String encender() {
        return "Computadora encendida";
    }

    @Override
    public String apagar() {
        return "Computadora apagada";
    }
    
    public String iniciarSesion(String usuario){
        return usuario+" ha iniciado sesión";
    }
    
    public String cerrarSesion(String usuario){
        return usuario+" ha cerrado sesión";
    }
    
    public String actualizar(){
        System.out.println("Actualizaciones pendientes");
        System.out.println("Actualizando...");
        System.out.println("Instalando...");
        return "Es necesario apagar el equipo para que las actualizaciones tomen efecto";
    }
       
}
