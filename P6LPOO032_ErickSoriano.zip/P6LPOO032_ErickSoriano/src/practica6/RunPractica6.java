/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica6;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author jorgeislas
 */
public class RunPractica6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entrada = new Scanner(System.in);
        Telefono tel = new Telefono();
        Computadora cp = new Computadora();
        ArrayList<Computadora> alcp = new ArrayList<>();
        ArrayList<Telefono> altel = new ArrayList<>();
        
        altel.add(tel);
        altel.add(tel);
        alcp.add(cp);
        alcp.add(cp);
        
        
        int i = 0;
        for (Telefono obj : altel){
            System.out.println("Ingrese la información del teléfono "+Integer.toString(++i)+" :");
            System.out.println("Marca:");
            obj.setMarca(entrada.nextLine());
            System.out.println("Modelo:");
            obj.setModelo(entrada.nextLine());
            obj.setVolumen(30 + i*10);
            System.out.println("");
        }
        System.out.println("");
        System.out.println("");
        i = 0;
        for (Computadora obj : alcp) {
            System.out.println("Ingrese la información de la laptop "+Integer.toString(++i)+" :");
            System.out.println("Marca:");
            obj.setMarca(entrada.nextLine());
            System.out.println("Modelo:");
            obj.setModelo(entrada.nextLine());
            obj.setVolumen(20 + i*10);
            System.out.println("Nombre de usuario:");
            obj.setUsuario(entrada.nextLine());
            System.out.println("");
        }
        System.out.println("");
        System.out.println("Telefonos:");
        System.out.println("");
        
        for(Telefono dispositivo:altel){
            System.out.println("");
            System.out.print(dispositivo.getMarca()+" ");
            System.out.println(dispositivo.getModelo()+" :");
            System.out.println(dispositivo.encender());
            System.out.println("Volumen "+Integer.toString(dispositivo.getVolumen())+"%");
            System.out.println(dispositivo.hacerLlamada("Gustavo I."));
            System.out.println(dispositivo.bajarVolumen(dispositivo.getVolumen()));
            System.out.println(dispositivo.hacerLlamada(12532341));
            System.out.println(dispositivo.apagar());
        }
        
        System.out.println("");
        System.out.println("Computadoras:");
        System.out.println("");
        
        for(Computadora dispositivo:alcp){
            System.out.println("");
            System.out.print(dispositivo.getMarca()+" ");
            System.out.println(dispositivo.getModelo()+" :");
            System.out.println(dispositivo.encender());
            System.out.println(dispositivo.iniciarSesion(dispositivo.getUsuario()));
            System.out.println("Volumen "+Integer.toString(dispositivo.getVolumen())+"%");
            System.out.println(dispositivo.bajarVolumen(dispositivo.getVolumen()));
            System.out.println(dispositivo.actualizar());
            System.out.println(dispositivo.subirVolumen(dispositivo.getVolumen()));
            System.out.println(dispositivo.cerrarSesion(dispositivo.getUsuario()));
            System.out.println(dispositivo.apagar());
        }
    }
    
}
