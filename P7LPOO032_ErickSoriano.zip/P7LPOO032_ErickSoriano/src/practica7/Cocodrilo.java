/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Erick
 */
public class Cocodrilo extends Animal{

    @Override
    public String caminar(double caminar) {
        return "El cocodrilo caminó " + Double.toString(caminar) + "km";
    }
    private String comer(String comida){
        return "El cocodrilo está comiendo " + comida;
    }
    
    public Cocodrilo(String comida){
        System.out.println(comer(comida));
    }
    
}
