/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Erick
 */
public class Gato extends Animal{

    /**
     * @return the raza
     */
    public String getRaza() {
        return raza;
    }

    /**
     * @param raza the raza to set
     */
    public void setRaza(String raza) {
        this.raza = raza;
    }
    
    private String raza;
    
    public String maullar(){
        return "El gato está maullando";
    }
    private String comer(String comida){
        return "El gato está comiendo " + comida;
    }
    
    
    
    @Override
    public String caminar(double caminar) {
        return "El gato caminó " + Double.toString(caminar) + "km";
    }
    
    public Gato(String comida){
        System.out.println(comer(comida));
    }
}
