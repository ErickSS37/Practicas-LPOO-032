/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Erick
 */
public class Gorrion extends Animal{

    @Override
    public String caminar(double caminar) {
        return "El gorrión caminó " + Double.toString(caminar) + "km";
    }
    
    private String comer(String comida){
        return "El gorrión está comiendo " + comida;
    }
    
    public Gorrion(String comida){
        System.out.println(comer(comida));
    }
    
}
