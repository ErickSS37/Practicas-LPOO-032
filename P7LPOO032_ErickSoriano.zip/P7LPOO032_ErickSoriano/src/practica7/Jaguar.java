/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Erick
 */
public class Jaguar extends Animal{

    @Override
    public String caminar(double caminar) {
        return "El jaguar caminó " + Double.toString(caminar) + "km";
    }
    
    private String comer(String comida){
        return "El jaguar está comiendo " + comida;
    }
    
    public Jaguar(String comida){
        System.out.println(comer(comida));
    }
}
