/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Erick
 */
public class Perro extends Animal{
    
    public String color;
    
    public String ladrar(){
        return "El perro está ladrando";
    }
    private String comer(String comida){
        return "El perro está comiendo " + comida;
    }
    @Override
    public String caminar(double caminar) {
        return "El perro caminó " + Double.toString(caminar) + "km";
    }
    
    public Perro(String comida){
        System.out.println(comer(comida));
    }
    
}
