/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Erick
 */
public class RunPractica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        double cant;
        double prom;
        String str;
        Animal gato = new Gato("atún");
        Animal perro = new Perro("croquetas");
        Animal gorrion = new Gorrion("semillas");
        Animal cocodrilo = new Cocodrilo("una rana");
        Animal jaguar = new Jaguar("un venado");
        
        ArrayList<Animal> an = new ArrayList<>();
        ArrayList<Double> d = new ArrayList<>();
        
        an.add(gato);
        an.add(perro);
        an.add(gorrion);
        an.add(cocodrilo);
        an.add(jaguar);
        
        System.out.println("Indique la distancia que recorrió cada animal respectivamente");
        for(Animal a:an){
            cant = entrada.nextDouble();
            System.out.println(a.caminar(cant));
            d.add(cant);
        }
        cant = 0;
        for(Double n:d){
            cant += n;
        }
        prom = cant / d.size();
        
        System.out.println("La distancia promedio recorrida por los animales fue de " + Double.toString(prom) + "km");
        
        
    }
    
}
