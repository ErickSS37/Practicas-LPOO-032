/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica8;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Erick
 */
public class RunPractica8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        Utils f = new Utils();
        String str;
        
        System.out.println("Escriba el nombre del archivo con el que trabajar:");
        str = entrada.next();
        File file = new File(str + ".txt");
        System.out.println("");
        System.out.println("Archivo " + file.getName() + ": ");
        System.out.println("Modifique el archivo:");
        str = entrada.next();
        f.writeFile(file, str);
        System.out.println("");
        System.out.println("El contenido del archivo es el siguiente:");
        f.readFile(file);
        System.out.println("");
        System.out.print("Modifique el archivo nuevamente:");
        str = entrada.next();
        f.writeFile(file, str);
        System.out.println("");
        System.out.println("El contenido final es:");
        f.readFile(file);
        
    }
    
}
