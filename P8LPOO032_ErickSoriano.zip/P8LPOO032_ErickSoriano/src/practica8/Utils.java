/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica8;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Erick
 */
public class Utils {
    private int c = 0;
    public void writeFile(File fileName, String txt) {
        try {
            FileWriter fw = new FileWriter(fileName);
            fw.write(txt);
            fw.close();
            System.out.println("");
            System.out.println("Fin del archivo");
            System.out.println("");
            System.out.println("El contenido fue escrito:");
            readFile(fileName);
        } catch (IOException ex) {
            System.out.println("Ocurrió un error");
        }
    }
    public void readFile(File fileName){
        try{
            FileReader fr = new FileReader(fileName);
            System.out.println("Archivo " + fileName.getName() + ": ");
            System.out.println("");
            do{
                System.out.print((char)(c = fr.read()) + "");
            }while(c != '\n');
            System.out.println("");
            System.out.println("Fin del archivo");
            fr.close();
        } catch (IOException ex) {
            System.out.println("Ocurrió un error");
        }
    }
}
