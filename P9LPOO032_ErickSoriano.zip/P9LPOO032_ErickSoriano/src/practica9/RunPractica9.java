/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica9;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class RunPractica9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person p1 = new Person("A" , "a1");
        Person p2 = new Person("B" , "a2");
        Person p3 = new Person("C" , "a3");
        Staff stf1 = new Staff("D","b1","DD", 20000);
        Staff stf2 = new Staff("E","b2","EE", 25000);
        Staff stf3 = new Staff("F","b3","FF", 22500);
        Student std1 = new Student ("H", "c1", "H1", 3, 3000);
        Student std2 = new Student ("I", "c2", "I1", 7, 3000);
        Student std3 = new Student ("J", "c3", "J1", 6, 3000);
        
        ArrayList<Person> al = new ArrayList<Person>();
        al.add(p1);
        al.add(p2);
        al.add(p3);
        al.add(stf1);
        al.add(stf2);
        al.add(stf3);
        al.add(std1);
        al.add(std2);
        al.add(std3);
        for(Person a:al){
            System.out.println(a.toString()+"\n");
        }
    }
    
}
