/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica9;

/**
 *
 * @author Erick
 */
public class Staff extends Person{
    private String school;
    private double pay;
    private String dirname;
    
    public Staff (String name, String address, String school, double pay){
        super(name, address);
        this.dirname = name + ", address = " + address;
        this.school = school;
        this.pay = pay;
    }
    
    @Override
    public String toString(){
        return "Staff[ Person[name = " + this.dirname + "], school = " + this.school + ", pay =" + Double.toString(this.pay) + " ]";
    }
    
}
