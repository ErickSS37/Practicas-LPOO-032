package Conn;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell
 */
public class DbConnESS {
    public String driver = "com.mysql.cj.jdbc.Driver";
    public String hostname = "127.0.0.1";
    public String port = "3306";
    public String user = "root";
    public  String password = "1234";
    public String db = "practicas";
    public String myUrl = "jdbc:mysql://"+hostname+":"+port+"/"+db;
    
    public void insert(String fn, String ln) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryIn = "INSERT INTO users (first_name, last_name) " +"VALUES ('"+fn+"', '"+ln+"')";
//          String qryD = "DELETE FROM users WHERE first_name =" + "'"+fn+"'";
          System.out.println(qryIn);
          st.executeUpdate(qryIn);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public void delete(int id) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryD = "DELETE FROM users WHERE id = "+id;
          System.out.println(qryD);
          st.executeUpdate(qryD);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public ResultSet select() throws ClassNotFoundException{
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryS = "SELECT * FROM users";
          System.out.println(qryS);
          System.out.println("Cerrando conexión");
          conn.close();
          return st.executeQuery(qryS);
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
        return null;
    }
    public void update(String fn, String ln, int id) throws ClassNotFoundException{
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryU = "UPDATE users SET first_name = '"+fn+"', last_name = '"+ln+"' WHERE id = "+id ;
          System.out.println(qryU);
          st.executeUpdate(qryU);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
}
