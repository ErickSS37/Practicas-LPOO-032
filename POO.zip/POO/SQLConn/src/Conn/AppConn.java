/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author Erick
 */
public class AppConn {
    public static String driver = "com.mysql.cj.jdbc.Driver";
    public static String hostname = "127.0.0.1";
    public static String port = "3306";
    public static String user = "root";
    public static String password = "1234";
    public static String db = "webapp";
    public String myUrl = "jdbc:mysql://"+hostname+":"+port+"/"+db;
    
    public void agregar(String nombre, double precio) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryIn = "INSERT INTO producto (nombre, precio) VALUES ('"+nombre+"', "+precio+");";
          System.out.println(qryIn);
          st.executeUpdate(qryIn);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public void borrar(int id) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryD = "DELETE FROM producto WHERE id = " + id+";";
          System.out.println(qryD);
          st.executeUpdate(qryD);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public ResultSet mostrar() throws ClassNotFoundException{
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryS = "SELECT * FROM producto;";
          System.out.println(qryS);
          ResultSet rs = st.executeQuery(qryS);
          System.out.println("Cerrando conexión");
          conn.close();
          return rs;
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
        return null;
    }
    public void update(String nombre, double precio, int id) throws ClassNotFoundException{
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryU = "UPDATE producto SET nombre = '"+nombre+"', precio = "+precio+" WHERE id = "+id+";";
          System.out.println(qryU);
          st.executeUpdate(qryU);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    
    
}
