/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Conn.AppConn;
import Modelos.Productos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Erick
 */
@WebServlet(name = "MostrarPorductos", urlPatterns = {"/MostrarProductos"})
public class MostrarProductos extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        
        Productos p = new Productos();
        
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            double total = 0;
            AppConn con = new AppConn();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MostrarProductos</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MostrarProductos at " + request.getContextPath() + "</h1>");
            out.println("<br><a href=\"AgregarProducto.html\">Agregar Producto</a><br>");
            Class.forName(AppConn.driver);
            try (Connection conn = DriverManager.getConnection(con.myUrl, AppConn.user, AppConn.password)){
                Statement st = conn.createStatement();
                String qryS = "SELECT * FROM producto;";
                System.out.println(qryS);
                ResultSet rs = st.executeQuery(qryS);
                while(rs.next()){
                    p.setId(rs.getInt("id"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getDouble("precio"));
                    total += p.getPrecio();
                    out.println("<h3>#"+p.getId()+" - "+p.getNombre()+" a $"+p.getPrecio()+" MX</h3><br>");
                    System.out.println(p.getId() + " "+ p.getNombre()+" "+p.getPrecio()+"\n" );
                    out.println("<h4>Modificar información</h4>"); 
                    out.println("<form action = \"ModificarProducto\" method=\"get\">"); 
                    out.println("<label>Nuevo Nombre del Producto</label>");
                    out.println("<input type=\"text\" name=\"nombre\" required> <br>");
                    out.println("<label>Nuevo Precio del producto</label>");
                    out.println("<input type=\"number\" name=\"precio\" min=\"1\" pattern=\"^[0-9]+\" required><br>");
                    out.println("<label>Id</label>");
                    out.println("<input type=\"number\" name=\"id\" min=\"1\" pattern=\"^[0-9]+\" required><br>");
                    out.println("<input type=\"submit\" value=\"Modificar\">");
                    out.println("</form>");
                    out.println("<br><a href=\"EliminarProducto?id="+p.getId()+"\">Eliminar</a><hr><br>");
                }
                System.out.println("Cerrando conexión");
                conn.close();
            }
            out.println("<h4>Total a Pagar: $"+total+" MX</h4>");
            out.println("</body>");
            out.println("</html>");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MostrarProductos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(MostrarProductos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(MostrarProductos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
