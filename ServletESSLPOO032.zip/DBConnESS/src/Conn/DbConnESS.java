package Conn;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell
 */
public class DbConnESS {
    protected String driver = "com.mysql.cj.jdbc.Driver";
    protected String hostname = "127.0.0.1";
    protected String port = "3306";
    protected String user = "root";
    protected String password = "1234";
    protected String db = "practicas";
    protected String myUrl = "jdbc:mysql://"+hostname+":"+port+"/"+db;
    
    public void insert(String fn, String ln) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryIn = "INSERT INTO users (first_name, last_name) " +"VALUES ('"+fn+"', '"+ln+"')";
//          String qryD = "DELETE FROM users WHERE first_name =" + "'"+fn+"'";
          System.out.println(qryIn);
          st.executeUpdate(qryIn);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public void delete(String fn) throws ClassNotFoundException{
        // create a mysql database connection
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryD = "DELETE FROM users WHERE first_name = " + fn;
          System.out.println(qryD);
          st.executeUpdate(qryD);
          System.out.println("Cerrando conexión");
          conn.close();
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
    }
    public ResultSet select() throws ClassNotFoundException{
        Class.forName(driver);
        try (Connection conn = DriverManager.getConnection(myUrl, user, password)){
          Statement st = conn.createStatement();
          String qryS = "SELECT * FROM users";
          System.out.println(qryS);
          System.out.println("Cerrando conexión");
          conn.close();
          return st.executeQuery(qryS);
        }
        catch(Exception e){
            System.err.println("Got an exception");
            System.err.println(e.getMessage());
        }
        return null;
    }
}
